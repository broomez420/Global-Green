Sample configuration files for:

SystemD: globalgreend.service
Upstart: globalgreend.conf
OpenRC:  globalgreend.openrc
         globalgreend.openrcconf
CentOS:  globalgreend.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
